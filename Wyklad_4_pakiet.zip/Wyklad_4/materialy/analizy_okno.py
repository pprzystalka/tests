"""Analizy rzeczywistego sygnału F2: Pressure_Tank103. Python 3 + numpy, scipy, matplotlib.
Uruchomienie: python analizy_okno.py. Wyniki: Rys/analiza_*.pdf i CSV.
Dane źródłowe F2_data.csv i cycles.txt dostarczone przez użytkownika.
"""
from pathlib import Path
import json
import pandas as pd
import numpy as np
from scipy import stats
from scipy.spatial.distance import cdist
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
(ROOT/'Rys').mkdir(exist_ok=True)
FS=1; N=60; STEP=1; TFAULT=278
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans','pdf.fonttype':42})
data=pd.read_csv(ROOT/'F2_data.csv')
# Granice cykli są indeksami wierszy, obustronnie domkniętymi.
refdata=data.iloc[0:348]
caldata=data.iloc[1197:1482]
test=data.iloc[634:1197].copy()
reference=refdata.Pressure_Tank103.to_numpy()
calibration=caldata.Pressure_Tank103.to_numpy()
r=test.Pressure_Tank103.to_numpy()
time=pd.to_datetime(test.MeasureTime)
t=(time-time.iloc[0]).dt.total_seconds().to_numpy()
assert np.all(np.diff(t)==1), 'Nieregularny krok w wybranym fragmencie'
assert np.all(test.Fault.iloc[:278]==0) and np.all(test.Fault.iloc[278:]==1)
mu=float(np.mean(reference));sd=float(np.std(reference,ddof=1));ref=reference
edges=np.r_[-np.inf,np.arange(0,301,10),np.inf]
tol=.2*sd
def apen(x,m=2):
    def phi(m):
        v=np.lib.stride_tricks.sliding_window_view(x,m)
        counts=(cdist(v,v,metric='chebyshev')<=tol).mean(axis=1)
        return np.log(counts).mean()
    return phi(m)-phi(m+1)

def boxdim(x):
    # Stałe skalowanie amplitudy: 1 jednostka = 6 sigma odniesienia.
    # Próbkujemy odcinki łamanej, aby pokryć także pola między próbkami.
    xx=np.linspace(0,1,len(x)); yy=(x-mu)/(6*sd)
    scales=np.array([1/4,1/8,1/16,1/32]);counts=[]
    for e in scales:
        pts=[]
        for i in range(len(x)-1):
            n=max(2,int(np.ceil(max(xx[i+1]-xx[i],abs(yy[i+1]-yy[i]))/e*4))+1)
            pts.append(np.column_stack([np.linspace(xx[i],xx[i+1],n),np.linspace(yy[i],yy[i+1],n)]))
        coords=np.floor(np.vstack(pts)/e).astype(int)
        counts.append(len(np.unique(coords,axis=0)))
    return float(np.polyfit(np.log(1/scales),np.log(counts),1)[0])

def hurst(x):
    scales=np.array([6,8,10,15,20]);rs=[];valid_scales=[]
    for n in scales:
        blocks=x[:len(x)//n*n].reshape(-1,n)
        std=blocks.std(axis=1,ddof=1);valid=std>1e-12
        if not valid.any():continue
        blocks=blocks[valid];std=std[valid]
        z=np.cumsum(blocks-blocks.mean(axis=1,keepdims=True),axis=1)
        value=np.mean(np.ptp(z,axis=1)/std)
        if value>0:rs.append(value);valid_scales.append(n)
    return float(np.polyfit(np.log(valid_scales),np.log(rs),1)[0]) if len(rs)>=3 else np.nan

def cusum(x):
    s=0
    for v in x:s=max(0,s+v-mu-.5*sd)
    return s/sd

def glr(x):
    best=0.
    for tau in range(len(x)-19):
        a=x[tau:];v=max(np.var(a),(.1*sd)**2)
        ll=len(a)*np.log(sd/np.sqrt(v))+np.sum((a-mu)**2)/(2*sd**2)-np.sum((a-a.mean())**2)/(2*v)
        best=max(best,ll)
    return best

def ph(x):
    m=0.;low=0.;total=0.
    for k,v in enumerate(x,1):
        total+=v;m+=v-total/k-.05*sd;low=min(low,m)
    return (m-low)/sd

def lepage(x):
    pooled=np.r_[ref,x]; ranks=stats.rankdata(pooled);n=len(x);m=len(ref);nt=n+m
    scores=np.minimum(ranks,nt+1-ranks)
    def standardize(v):
        mean=v.mean();variance=n*m/(nt*(nt-1))*np.sum((v-mean)**2)
        return (v[m:].sum()-n*mean)/np.sqrt(variance) if variance>0 else 0.
    return standardize(ranks)**2+standardize(scores)**2

def runs(x):
    median=np.median(x);x=x[x!=median];signs=x>median;n1=signs.sum();n2=len(x)-n1;n=len(x)
    if n1==0 or n2==0 or n<3:return 0.
    R=1+np.count_nonzero(signs[1:]!=signs[:-1])
    er=1+2*n1*n2/n;vr=2*n1*n2*(2*n1*n2-n)/(n*n*(n-1))
    return abs((R-er)/np.sqrt(vr))

def entropy(x):
    h=np.histogram(x,edges)[0];p=h[h>0]/len(x);return -np.sum(p*np.log2(p))
methods=[('shannon','Entropia Shannona','H [bit]',entropy,True),('apen','Approximate Entropy','ApEn',apen,True),('fraktal','Wymiar pudełkowy','D',boxdim,True),('hurst','Wykładnik Hursta','Hᵤ',hurst,True),('cusum','CUSUM w oknie','S⁺ / σ₀',cusum,False),('glr','GLR w oknie','G',glr,False),('ph','Page-Hinkley w oknie','PH / σ₀',ph,False),('lepage','Test Lepage’a','L',lepage,False),('runs','Test serii','|Z|',runs,False),('bartlett','Test Bartletta','B',lambda x:stats.bartlett(ref,x).statistic,False)]
ends=np.arange(N,len(r)+1,STEP);times=(ends-1)/FS
# Każdy wynik należy do chwili zakończenia okna [t-59,t] (60 próbek).
ce=np.arange(N,len(calibration)+1,STEP)
results={};csvcols=[times]
for key,name,label,fun,two in methods:
    train=np.array([fun(calibration[e-N:e]) for e in ce])
    values=np.array([fun(r[e-N:e]) for e in ends])
    low,high=(np.nanquantile(train,[.005,.995]) if two else (None,np.nanquantile(train,.99)))
    dd=values>high
    valid_values=np.isfinite(values)
    if two:dd|=values<low
    before=times<TFAULT;after=times>=TFAULT
    first=times[after & dd][0]-TFAULT if np.any(after&dd) else None
    results[key]={'name':name,'low':None if low is None else float(low),'high':float(high),'first_alarm_after_fault_s':None if first is None else float(first),'pre_alarm_percent':float(dd[before & valid_values].mean()*100),'post_alarm_percent':float(dd[after & valid_values].mean()*100),'invalid_windows':int((~valid_values).sum())}
    csvcols.extend([values,np.where(valid_values,dd.astype(float),np.nan)])
    fig,ax=plt.subplots(3,1,figsize=(7.5,4.1),sharex=True,gridspec_kw={'height_ratios':[1,1.15,.38]},layout='constrained')
    ax[0].plot(t,r,color='#194c78',lw=.7,label='Pressure_Tank103');ax[0].set_ylabel('[mbar]');ax[0].legend(loc='upper left',fontsize=8)
    ax[0].axvspan(240,299,color='#76adce',alpha=.45)
    ax[0].text(295,.96,'Window [240,299] s',transform=ax[0].get_xaxis_transform(),ha='right',va='top',fontsize=8,bbox={'facecolor':'white','alpha':.8,'edgecolor':'none'})
    ax[1].plot(times,values,color='#194c78',lw=1.1,label=key)
    ax[1].axhline(high,color='#ad3232',ls='--',lw=1,label='Threshold')
    if two:ax[1].axhline(low,color='#ad3232',ls='--',lw=1)
    idx=np.flatnonzero(times==299)[0];ax[1].plot([299],[values[idx]],'o',color='#047c91',ms=5)
    ax[1].set_ylabel(label);ax[1].legend(loc='upper left',fontsize=8,ncol=2)
    ax[2].step(times,dd.astype(int),where='post',color='#ad3232',lw=1);ax[2].set_yticks([0,1]);ax[2].set_ylim(-.15,1.2);ax[2].set_ylabel(r'$s_i[k]$');ax[2].set_xlabel('MeasureTime − t₀ [s]')
    for a in ax:
        a.axvspan(TFAULT,563,color='#f1af54',alpha=.13)
        a.axvline(TFAULT,color='#ae6919',ls=':',lw=1)
        a.grid(alpha=.18);a.set_xlim(0,563)
    fig.savefig(ROOT/'Rys'/f'analiza_{key}.pdf');plt.close(fig)
    print(key,results[key],flush=True)
# Sygnał rzeczywisty i zadanie regulatora.
fig,ax=plt.subplots(2,1,figsize=(7.5,4.1),sharex=True,layout='constrained',gridspec_kw={'height_ratios':[3,1]})
ax[0].plot(t,r,label='Pressure_Tank103',lw=1,color='#194c78')
ax[0].plot(t,test.SetPressureTank103_manual,label='SetPressureTank103_manual',lw=.9,color='gray',ls='--')
ax[0].set_ylabel('[mbar]');ax[0].legend(loc='upper left',fontsize=8,ncol=2)
ax[1].step(t,test.Fault,where='post',color='#ad3232');ax[1].set_ylabel('Fault');ax[1].set_yticks([0,1]);ax[1].set_ylim(-.1,1.2);ax[1].set_xlabel('MeasureTime − t₀ [s]')
for a in ax:a.axvspan(TFAULT,563,color='#f1af54',alpha=.15);a.axvline(TFAULT,color='#ae6919',ls=':');a.set_xlim(0,563);a.grid(alpha=.2)
fig.savefig(ROOT/'Rys'/'analiza_stanowisko.pdf');plt.close(fig)
fig,ax=plt.subplots(3,1,figsize=(7.5,4.1),sharex=True,layout='constrained')
for a,end in zip(ax,[220,299,360]):
    a.plot(t,r,lw=.55,color='#8a969f',label='Pressure_Tank103');a.legend(loc='upper right',fontsize=8);mask=(t>=end-59)&(t<=end);a.plot(t[mask],r[mask],color='#194c78',lw=1)
    a.axvspan(end-59,end,color='#76adce',alpha=.4);a.axvline(TFAULT,color='#ae6919',ls=':');a.set_ylabel('[mbar]');a.set_xlim(100,430);a.grid(alpha=.2)
    a.text(.015,.9,f't = {end} s: Window [{end-59},{end}] s',transform=a.transAxes,fontsize=9,bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
ax[-1].set_xlabel('MeasureTime − t₀ [s]');fig.savefig(ROOT/'Rys'/'analiza_okna.pdf');plt.close(fig)
np.savetxt(ROOT/'F2_wybrane_cykle.csv',np.column_stack([test.iloc[:,0],t,r,test.SetPressureTank103_manual,test.Fault]),delimiter=',',header='indeks_zrodlowy,t_s,Pressure_Tank103_mbar,SetPressureTank103_manual_mbar,Fault',comments='')
np.savetxt(ROOT/'wyniki_okien.csv',np.column_stack(csvcols),delimiter=',',header=','.join(['koniec_okna_s']+[col for i,m in enumerate(methods,1) for col in [m[0],f's_{i}[k]']]),comments='')
(ROOT/'parametry_analiz.json').write_text(json.dumps({'source':'F2_data.csv','signal':'Pressure_Tank103','test_rows_inclusive':[634,1196],'reference_rows_inclusive':[0,347],'calibration_rows_inclusive':[1197,1481],'fs_hz':FS,'window_samples':N,'step_samples':STEP,'fault_s':TFAULT,'reference_mean':mu,'reference_sd':sd,'apen_r':tol,'results':results},ensure_ascii=False,indent=2))
