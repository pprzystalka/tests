"""Dydaktyczny przykład interpretacji DAMADICS; nie pomiary FESTO."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
P=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':12,'font.family':'DejaVu Sans','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
t=np.arange(0,161);s=np.zeros(len(t))
for a,b in [(30,40),(90,100),(110,161)]:s[(t>=a)&(t<b)]=1
blue='#245977';red='#b33737';green='#26765e';orange='#ba7a12'
fig,ax=plt.subplots(figsize=(9,3.8),layout='constrained')
ax.axvspan(0,20,color='#ddd',alpha=.6)
ax.axvspan(20,80,color='#dcebf3',alpha=.7)
ax.axvspan(80,160,color='#e3efe7',alpha=.75)
ax.fill_between(t,0,s,where=(t>=20)&(t<80),step='post',color=red,alpha=.35)
ax.fill_between(t,0,s,where=t>=80,step='post',color=green,alpha=.4)
ax.step(t,s,where='post',color=blue,lw=2)
for x in [20,80,160]:ax.axvline(x,color='#777',ls=':',lw=1)
ax.text(50,1.43,'stan zdatny: 60 s',ha='center',color=blue,weight='bold')
ax.text(120,1.43,'uszkodzenie: 80 s',ha='center',color=green,weight='bold')
ax.text(35,.5,'10 s',ha='center',color=red,weight='bold')
ax.text(95,.5,'10 s',ha='center',color=green,weight='bold')
ax.text(135,.5,'50 s',ha='center',color=green,weight='bold')
ax.set_xticks([0,20,30,40,80,90,100,110,160]);ax.tick_params(axis='x',labelsize=10)
ax.set_yticks([0,1]);ax.set_ylabel(r'$s_i[k]$');ax.set_xlabel('t [s]');ax.set_xlim(0,162);ax.set_ylim(-.12,1.65)
ax.annotate(r'$t_{on}$',xy=(20,0),xytext=(20,1.13),ha='center')
ax.annotate(r'$t_f$',xy=(80,0),xytext=(80,1.13),ha='center')
ax.annotate(r'$t_h$',xy=(160,0),xytext=(158,1.13),ha='center')
fig.savefig(P/'Rys'/'damadics_udzialy.pdf');plt.close(fig)

fig,ax=plt.subplots(figsize=(9,3.8),layout='constrained')
ax.axvspan(80,160,color='#e3efe7',alpha=.7)
mask=t>=70;ax.step(t[mask],s[mask],where='post',color=blue,lw=2)
ax.axvline(80,color=orange,ls='--');ax.axvline(110,color=green,ls=':')
ax.text(80,1.5,'początek\nuszkodzenia',ha='center',va='top',color=orange)
ax.text(95,1.5,'alarm\nchwilowy',ha='center',va='top',color=blue)
ax.text(135,1.5,'alarm utrzymuje się\ndo końca oceny',ha='center',va='top',color=green)
for end,y,label,color in [(90,-.32,'pierwsza reakcja: 10 s',blue),(110,-.7,'opóźnienie DAMADICS: 30 s',green)]:
    ax.annotate('',xy=(80,y),xytext=(end,y),arrowprops={'arrowstyle':'<->','color':color,'lw':1.5})
    ax.text(112 if end==90 else 118,y,label,color=color,va='center',fontsize=11)
ax.set_xlim(70,162);ax.set_ylim(-.93,1.6);ax.set_xticks([80,90,100,110,160]);ax.set_yticks([0,1]);ax.set_ylabel(r'$s_i[k]$');ax.set_xlabel('t [s]')
fig.savefig(P/'Rys'/'damadics_opoznienie.pdf');plt.close(fig)
