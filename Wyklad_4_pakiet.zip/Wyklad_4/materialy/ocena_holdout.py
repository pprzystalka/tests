"""Zamrożony detektor ApEn na HOLDOUT: cykle 7 i 8.
Bez ponownej kalibracji. Brak interpolacji przez lukę; tylko pełne okna 60 s.
Ocena warunkowa na dostępnych oknach, z jawnym raportem pokrycia czasu.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'parametry_analiz.json').read_text())
N=config['window_samples']; m=2; r=config['apen_r']; h=config['results']['apen']['high']
assert N==60 and config['results']['apen']['low']==0
data=pd.read_csv(ROOT/'F2_data.csv')
d=data.iloc[1764:2328].copy()
t=(pd.to_datetime(d.MeasureTime)-pd.to_datetime(d.MeasureTime).iloc[0]).dt.total_seconds().to_numpy().astype(int)
x=d.Pressure_Tank103.to_numpy()
v=np.full(len(d),np.nan)
for k in range(N-1,len(d)):
    if not np.all(np.diff(t[k-N+1:k+1])==1):continue
    window=x[k-N+1:k+1]
    def phi(mm):
        vectors=np.lib.stride_tricks.sliding_window_view(window,mm)
        return np.log((cdist(vectors,vectors,metric='chebyshev')<=r).mean(axis=1)).mean()
    v[k]=phi(m)-phi(m+1)
valid=np.isfinite(v)
b=np.where(valid,(v>h).astype(float),np.nan)
state=np.zeros(len(d),dtype=int); n=0; memory=0
for k in range(len(d)):
    n=n+1 if b[k]==1 else 0
    if n>=3:memory=1
    state[k]=memory
# Pamięć pozostaje ustawiona przez brak danych; te czasy nie są oceniane.
s=np.where(valid,state.astype(float),np.nan)
fault=d.Fault.to_numpy().astype(int)
onset=int(t[np.flatnonzero(fault==1)[0]])
end=int(t[-1]+1)
pre=valid&(fault==0); post=valid&(fault==1)
assert onset==285 and end==593
assert pre.sum()==226 and post.sum()==220

def assess(a):
    indices=np.flatnonzero(valid&(a==1))
    # Zbocze wymaga sąsiedniej czasowo próbki i poprzedniego stanu 0.
    rises=[k for k in indices if k>0 and valid[k-1] and t[k]-t[k-1]==1 and a[k-1]==0]
    rising_after=[int(t[k]) for k in rises if t[k]>=onset]
    return dict(TN=int(np.sum(pre&(a==0))),FP=int(np.sum(pre&(a==1))),
                FN=int(np.sum(post&(a==0))),TP=int(np.sum(post&(a==1))),
                r_fd_observed=float(np.mean(a[pre])),r_td_observed=float(np.mean(a[post])),
                first_delay_s=rising_after[0]-onset if rising_after else None,
                last_observed_rising_delay_s=rising_after[-1]-onset if rising_after else None,
                alarm_at_end=bool(a[-1]==1))

results={'configuration':{'source_rows_inclusive':[1764,2327],'cycles':[7,8],
                         'm':m,'N':N,'r':r,'h':h,'confirmation_samples':3,
                         'reference_cycle':1,'calibration_cycle':5,'tuned_on_holdout':False},
         'time':{'ton_s':59,'fault_s':onset,'thor_s':end,
                 'observed_intervals_s':[[59,410],[498,593]],
                 'missing_intervals_s':[[410,439]],'rewarmup_intervals_s':[[439,498]],
                 'healthy_evaluated_s':226,'fault_evaluated_s':220,
                 'fault_total_s':308,'fault_unevaluated_s':88,
                 'fault_coverage':220/308,'overall_coverage_after_initial_warmup':446/534},
         'raw':assess(b),'latched':assess(s)}
assert results['raw']['TP']==62 and results['raw']['FP']==0
assert results['latched']['TP']==203 and results['latched']['FN']==17
assert results['latched']['first_delay_s']==17
(ROOT/'ocena_HOLDOUT.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
# Pełna siatka czasu zachowuje NaN dla braków; nie interpolujemy danych.
grid=pd.DataFrame(index=pd.Index(np.arange(end),name='t_s'))
rows=pd.DataFrame({'t_s':t,'source_row':d.index,'Pressure_Tank103':x,'Fault':fault,
                   'ApEn':v,'valid':valid.astype(int),'b_2[k]':b,'s_2[k]':s,
                   'internal_alarm_memory':state}).set_index('t_s')
grid=grid.join(rows)
grid['valid']=grid['valid'].fillna(0).astype(int)
grid['dt_evaluated_s']=grid['valid']
grid.to_csv(ROOT/'ocena_HOLDOUT.csv')

plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','pdf.fonttype':42,
                     'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(4,1,figsize=(8.6,5),sharex=True,layout='constrained',
                    gridspec_kw={'height_ratios':[1.3,1.3,.65,.65]})
ax[0].plot(grid.index,grid.Pressure_Tank103,color='#194c78',lw=.9,label='Pressure_Tank103')
ax[0].set_ylabel('[mbar]');ax[0].legend(loc='upper right',fontsize=8)
ax[1].plot(grid.index,grid.ApEn,color='#194c78',lw=1,label='ApEn')
ax[1].axhline(h,color='#ad3232',ls='--',lw=1,label=f'h = {h:.6f}')
ax[1].set_ylabel('ApEn');ax[1].legend(loc='upper right',fontsize=8,ncol=2)
for a,col,label in [(ax[2],'b_2[k]',r'$b_2[k]$'),(ax[3],'s_2[k]',r'$s_2[k]$')]:
    a.step(np.r_[grid.index,end],np.r_[grid[col],grid[col].iloc[-1]],where='post',color='#ad3232',lw=1.2,label=label)
    a.step(np.r_[grid.index,end],np.r_[grid.Fault,grid.Fault.iloc[-1]],where='post',color='gray',ls='--',lw=.8,label='Fault')
    a.set_ylim(-.15,1.3);a.set_yticks([0,1]);a.set_ylabel(label);a.legend(loc='upper right',fontsize=8,ncol=2)
for a in ax:
    a.axvspan(onset,end,color='#f1af54',alpha=.13)
    for left,right in [(0,59),(410,498)]:a.axvspan(left,right,color='gray',alpha=.23)
    a.axvline(onset,color='#ae6919',ls=':',lw=1)
    a.set_xlim(0,end);a.grid(alpha=.18)
ax[3].annotate('302 s',xy=(302,1),xytext=(335,.35),arrowprops={'arrowstyle':'->'},fontsize=9)
ax[-1].set_xlabel('MeasureTime − t₀ [s]')
fig.savefig(ROOT/'Rys'/'ocena_holdout_apen.pdf');plt.close(fig)

fig,ax=plt.subplots(figsize=(8.6,2.15),layout='constrained')
for segments,color in [([(59,226)],'#a6c9de'), ([(285,17)],'#f2ce87'),
                        ([(302,108),(498,95)],'#8cbdab'), ([(410,88)],'#cccccc')]:
    ax.broken_barh(segments,(.2,.6),facecolors=color)
for pos,label in [(172,'TN = 226 s'),(356,'TP = 108 s'),(454,'N/A: 88 s'),(545,'TP = 95 s')]:
    ax.text(pos,.5,label,ha='center',va='center',fontsize=10)
ax.annotate('FN = 17 s',xy=(293,.8),xytext=(262,1.16),ha='center',arrowprops={'arrowstyle':'->'},fontsize=10)
ax.set_ylim(0,1.4);ax.set_yticks([]);ax.set_xlim(50,599);ax.set_xticks([59,285,302,410,498,593]);ax.tick_params(axis='x',labelsize=9)
ax.set_xlabel('MeasureTime − t₀ [s]')
fig.savefig(ROOT/'Rys'/'ocena_holdout_czasy.pdf');plt.close(fig)
print(json.dumps(results,indent=2,ensure_ascii=False))
