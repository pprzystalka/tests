from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
d=pd.read_csv(P/'ocena_HOLDOUT.csv')
plt.rcParams.update({'font.size':12,'font.family':'DejaVu Sans','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(2,1,figsize=(9,3.4),sharex=True,layout='constrained')
for a,col,label,color in [(ax[0],'Fault','Fault','#194c78'),(ax[1],'s_2[k]',r'$s_2[k]$','#26765e')]:
    a.step(np.r_[d.t_s,593],np.r_[d[col],d[col].iloc[-1]],where='post',lw=2,color=color)
    a.set_ylabel(label);a.set_yticks([0,1]);a.set_ylim(-.18,1.3);a.set_xlim(0,593)
    a.axvspan(0,59,color='#ddd',alpha=.65)
    a.axvspan(410,498,color='#ddd',alpha=.65)
    a.axvline(285,ls=':',color='#194c78');a.grid(alpha=.15)
ax[0].annotate('285 s',xy=(285,1),xytext=(320,.4),arrowprops={'arrowstyle':'->'})
ax[1].annotate('302 s',xy=(302,1),xytext=(337,.4),arrowprops={'arrowstyle':'->'})
ax[-1].set_xlabel('MeasureTime − t₀ [s]')
fig.savefig(P/'Rys'/'holdout_porownanie.pdf')
