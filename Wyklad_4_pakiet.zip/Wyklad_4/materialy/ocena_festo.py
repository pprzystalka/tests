"""Ocena F2: ApEn bez podtrzymania i z potwierdzeniem + pamięcią alarmu.
Uruchom po analizy_okno.py. Fault jest używany wyłącznie do oceny.
Pamięć resetowana tylko na początku całego eksperymentu, nie na granicy Fault.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
w = pd.read_csv(ROOT/'wyniki_okien.csv')
d = pd.read_csv(ROOT/'F2_data.csv').iloc[634:1197].copy()
t = (pd.to_datetime(d.MeasureTime)-pd.to_datetime(d.MeasureTime).iloc[0]).dt.total_seconds().to_numpy()
tw = w.koniec_okna_s.to_numpy()
assert np.all(np.diff(t)==1) and np.all(np.diff(tw)==1)
raw = w['s_2[k]'].to_numpy().astype(int)
confirmed = np.zeros_like(raw)
for k in range(2,len(raw)):
    confirmed[k] = int(np.all(raw[k-2:k+1]))
latched = np.maximum.accumulate(confirmed)
truth = d.Fault.to_numpy()[tw.astype(int)].astype(int)
pre = truth==0
post = truth==1
assert pre.sum()==219 and post.sum()==285

def intervals(s):
    change=np.diff(np.r_[0,s,0])
    return [[int(tw[a]),int(tw[b-1]+1)] for a,b in zip(np.flatnonzero(change==1),np.flatnonzero(change==-1))]

def assess(s):
    rising=tw[np.flatnonzero(np.diff(np.r_[0,s])==1)]
    rising=rising[rising>=278]
    return dict(TN=int(np.sum(pre & (s==0))),FP=int(np.sum(pre & (s==1))),
                FN=int(np.sum(post & (s==0))),TP=int(np.sum(post & (s==1))),
                r_fd=float(s[pre].mean()),r_td=float(s[post].mean()),
                first_delay_s=float(rising[0]-278) if len(rising) else None,
                last_rising_delay_s=float(rising[-1]-278) if len(rising) else None,
                alarm_at_end=bool(s[-1]),alarm_intervals_s=intervals(s))

results={'configuration':{'N':60,'m':2,'r':20.123729979254293,'h':0.1607826467441209,
                         'confirmation_samples':3,'ton_s':59,'tfrom_s':278,'thor_s':563,
                         'hold':'until explicit reset; none inside this experiment',
                         'evaluation':'illustrative retrospective example, not independent validation'},
         'raw':assess(raw),'latched':assess(latched)}
assert results['raw']['TP']==102 and results['raw']['FP']==0
assert results['latched']['TP']==264 and results['latched']['FN']==21
assert results['latched']['last_rising_delay_s']==21
(ROOT/'ocena_F2.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
pd.DataFrame({'t_s':tw,'Fault':truth,'ApEn':w.apen,'b_2[k]':raw,
              'confirmation':confirmed,'s_2[k]':latched,'dt_s':np.ones(len(tw))}).to_csv(ROOT/'ocena_F2.csv',index=False)

plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','pdf.fonttype':42,
                     'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(4,1,figsize=(8.6,5.0),sharex=True,layout='constrained',
                    gridspec_kw={'height_ratios':[1.3,1.3,.65,.65]})
ax[0].plot(t,d.Pressure_Tank103,color='#194c78',lw=.9,label='Pressure_Tank103')
ax[0].set_ylabel('[mbar]');ax[0].legend(loc='upper right',fontsize=8)
ax[1].plot(tw,w.apen,color='#194c78',lw=1,label='ApEn')
ax[1].axhline(results['configuration']['h'],color='#ad3232',ls='--',lw=1,label='h = 0.160783')
ax[1].set_ylabel('ApEn');ax[1].legend(loc='upper right',fontsize=8,ncol=2)
for a,s,label in [(ax[2],raw,r'$b_2[k]$'),(ax[3],latched,r'$s_2[k]$')]:
    a.step(np.r_[tw,563],np.r_[s,s[-1]],where='post',color='#ad3232',lw=1.2,label=label)
    a.step(np.r_[t,563],np.r_[d.Fault.to_numpy(),1],where='post',color='gray',ls='--',lw=.8,label='Fault')
    a.set_ylim(-.15,1.3);a.set_yticks([0,1]);a.set_ylabel(label);a.legend(loc='upper right',fontsize=8,ncol=2)
for a in ax:
    a.axvspan(0,59,color='gray',alpha=.15)
    a.axvspan(278,563,color='#f1af54',alpha=.15)
    a.axvline(278,color='#ae6919',ls=':',lw=1)
    a.set_xlim(0,563);a.grid(alpha=.18)
ax[3].annotate('299 s',xy=(299,1),xytext=(330,.35),arrowprops={'arrowstyle':'->'},fontsize=9)
ax[-1].set_xlabel('MeasureTime − t₀ [s]')
fig.savefig(ROOT/'Rys'/'ocena_festo_apen.pdf')
plt.close(fig)

fig,ax=plt.subplots(figsize=(8.6,2.1),layout='constrained')
ax.broken_barh([(59,219)],(.2,.6),facecolors='#a6c9de')
ax.broken_barh([(278,21)],(.2,.6),facecolors='#f2ce87')
ax.broken_barh([(299,264)],(.2,.6),facecolors='#8cbdab')
for x,text in [(168,'TN = 219 s'),(425,'TP = 264 s')]:ax.text(x,.5,text,ha='center',va='center',fontsize=12)
ax.annotate('FN = 21 s',xy=(288,.8),xytext=(245,1.15),ha='center',arrowprops={'arrowstyle':'->'})
ax.set_ylim(0,1.4);ax.set_yticks([]);ax.set_xlim(50,568);ax.set_xticks([59,278,299,563]);ax.set_xlabel('MeasureTime − t₀ [s]')
fig.savefig(ROOT/'Rys'/'ocena_festo_czasy.pdf');plt.close(fig)
print(json.dumps(results,indent=2,ensure_ascii=False))
