# Wykład 4 — notatki prowadzącego

Wersja dla studiów magisterskich, 90 minut. Autorska przebudowa dydaktyczna na podstawie materiałów użytkownika; bez afiliacji ani deklaracji zgodności z programem MIT. Styl pracy: problem, wyprowadzenie, przewidywanie, eksperyment, krytyczna ocena.

Plan części głównej: 90 minut. Dodatki poza podstawowym czasem.

## 1. Kiedy zmiana sygnału oznacza uszkodzenie? — 2 min

Otwórz pytaniem: ciśnienie zmieniło się o 50 mbar — czy należy zatrzymać proces? Zbierz dwie odpowiedzi, jeszcze ich nie oceniaj.

## 2. Cel: zaprojektować i obronić detektor — 2 min

Przedstaw rezultat zajęć jako decyzję projektową, nie zapamiętanie katalogu nazw.

## 3. Przypadek przewodni: zbiornik pod ciśnieniem — 3 min

Nie utożsamiaj F2 automatycznie z fizyczną awarią. Nazwa cyberatak pochodzi z cycles.txt; dane nie dokumentują jego mechanizmu.

## 4. Trzy różne pytania diagnostyczne — 2 min

Poproś o przykład czujnika z offsetem i nieszczelności dających podobny symptom.

## 5. Najpierw określ koszt błędnej decyzji — 3 min

Nie podawaj arbitralnego progu jako standardu. Zapytaj, czy ten sam próg pasuje do laboratorium i instalacji bezpieczeństwa.

## 6. Model myślowy: pomiar zawiera kilka przyczyn — 3 min

To model dydaktyczny, nie zidentyfikowany model stanowiska. Wpływ awarii bywa nieliniowy i nieaddytywny.

## 7. Residuum porównuje pomiar z oczekiwaniem — 4 min

Wyprowadź różnicę między błędem nadążania y-u a residuum względem modelu dynamicznego. Na przejściu y-u może być duże bez awarii.

## 8. Ćwiczenie: stały próg podczas zmiany zadania — 6 min

Daj minutę w parach. Odpowiedź: niemal zawsze alarm; próg większy niż 50 mbar zmniejsza czułość; odniesienie musi zależeć od zadania i dynamiki. Dla 200 mbar nominalny poziom dwustronny wynosi ok. 0,27%, tylko przy tych założeniach.

## 9. Rzeczywisty przebieg: obejrzyj zadanie i etykietę — 3 min

Poproś studentów o wskazanie prawidłowych przejść zanim pokażesz wskaźniki. Etykieta Fault nie jest wejściem detektora.

## 10. Okno jest częścią specyfikacji detektora — 3 min

Narysuj okno przecinające początek F2. Wyjaśnij różnicę między liczbą próbek a rozpiętością czasu.

## 11. Dobierz statystykę do hipotezy o zmianie — 3 min

Nie omawiaj dziesięciu wyprowadzeń. Zapytaj, czy wzrost wariancji przy skoku zadania jest anomalią.

## 12. ApEn porównuje krótkie wzorce — 4 min

Intuicja: czy podobne fragmenty pozostają podobne po dopisaniu kolejnej próbki? To nie entropia histogramu i nie dowód losowości.

## 13. Zamroź odniesienie przed testem — 3 min

Pokaż granice cykli w cycles.txt. Nie losuj sąsiadujących okien do train/test: współdzielą 59 z 60 próbek.

## 14. Jak wygląda ApEn na cyklach demonstracyjnych? — 3 min

Zestaw trzy poziomy: pomiar, wskaźnik, chwilowe przekroczenie. Zapytaj, czy etykieta Fault wymusza wzrost wskaźnika w każdej chwili.

## 15. Od przekroczenia do zapamiętanego zdarzenia — 4 min

Policz na tablicy dla sekwencji 0,1,1,0,1,1,1,0: potwierdzenie przy siódmej próbce, pamięć utrzymana w ósmej. Specyfikacja resetu jest konieczna w eksploatacji.

## 16. Potwierdzenie ma koszt i nie daje gwarancji — 3 min

Wyjaśnij różnicę między nominalną częstością przekroczeń na kalibracji a własnością całego systemu w nowym eksperymencie.

## 17. Przerwa na decyzję projektową — 6 min

Dwie minuty na dyskusję. Pamięć jest naturalna dla wykrycia zdarzenia, problematyczna jako estymata aktualnego stanu; potrzebny reset operatora lub niezależny warunek powrotu.

## 18. HOLDOUT: pokaż dane przed tabelą wyników — 3 min

Najpierw wskaż początek F2 w 285 s, alarm w 302 s i przerwę w danych. Dopiero potem odczytaj metryki.

## 19. Niepewność danych musi pozostać widoczna — 4 min

Rozróżnij 29 s braków pomiarowych i 59 s rozgrzewki. Łącznie 88 s F2 jest poza oceną; nie wolno zaliczyć tego czasu jako TN ani FN bez osobnej polityki.

## 20. Macierz pomyłek dotyczy ocenionego czasu — 3 min

Nie raportuj przedziału ufności liczonego z 220 niezależnych prób Bernoulliego: są to zależne próbki jednego zdarzenia.

## 21. Trzy liczby i ich zakres ważności — 3 min

Wskaźniki inspirowane oceną DAMADICS, zaadaptowane do maski niepełnych danych. Nie przypisuj benchmarkowi progów akceptacji.

## 22. Pamięć zmienia wynik: oceń znaczenie metryki — 3 min

Odpowiedź: zmieniła się logika i semantyka. Podtrzymanie bywa właściwe, ale nie jest dowodem poprawy zdolności ApEn do bieżącego rozpoznawania stanu.

## 23. Czy projekt spełnia wymagania? — 3 min

Nie pozwól uznać detektora za zaakceptowany na podstawie accuracy. Wymagania powinny być zapisane przed eksperymentem.

## 24. Następny eksperyment: oddziel poprawę od przecieku — 3 min

Model zależny od fazy jest hipotezą do sprawdzenia, nie zagwarantowaną poprawą. Zewnętrzna walidacja powinna obejmować inne dni i obciążenia.

## 25. Zadanie końcowe: obroń własną specyfikację — 8 min

Poproś jedną grupę o obronę resetu, drugą o obronę podziału danych. To projekt koncepcyjny; nie ma czasu na ponowne uczenie.

## 26. Co musi zawierać wiarygodna odpowiedź? — 3 min

Odpowiedź: pomija opóźnienie, przeoczenia, pokrycie oraz generalizację; wynik jest z jednego epizodu i z pamięcią.

## 27. Dodatek: entropia amplitud to nie regularność kolejności — dodatek

Użyj sekwencji 0,0,1,1 i 0,1,0,1: identyczny histogram, inna kolejność.

## 28. Dodatek: CUSUM jest testem określonej zmiany — dodatek

Ważne rozróżnienie implementacji okiennej i klasycznej. Nie opisuj wykresów demonstracji jako pełnej implementacji sekwencyjnej.

## 29. Dodatek: czego nie dowodzą krótkie okna? — dodatek

Traktuj te cechy jako wskaźniki porównawcze, dopóki nie zweryfikujesz założeń i własności estymatora.

## 30. Źródła i odtwarzalność — dodatek

Źródła bibliograficzne do dalszej lektury. Wyniki ilościowe pochodzą z dostarczonych danych i ponownie uruchomionych skryptów.

