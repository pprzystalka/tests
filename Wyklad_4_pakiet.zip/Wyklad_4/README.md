# Wykład 4 — wersja z zachowaniem oryginalnej formatki

Zachowano 71 slajdów, kolejność, teorię, wzory, dane, bibliografię, autora, motyw Madrid, proporcje 4:3, kolorystykę i stopkę.

Zmiany czytelności:
- wyrównanie tekstu przez RaggedRight zamiast pełnego justowania w miejscach, gdzie źródło używało justifying;
- odstępy 2 pt między punktami list numerowanych w pierwszej części teoretycznej (slajdy 1–23).

Nie usuwano ani nie przeredagowywano treści merytorycznej. Automatycznie porównano źródła: różnią się jedynie wymienionymi poleceniami składu i rozszerzeniami odtworzonych ilustracji. Dwie kompilacje LaTeX zakończyły się poprawnie, bez komunikatów o przepełnionych ramkach i niezdefiniowanych odwołaniach.

Ilustracje rastrowe odzyskano z oryginalnego PDF bez ponownego kodowania. Wykresy PDF odtworzono z dostarczonych skryptów i danych. Katalog Rys zawiera wszystkie ilustracje niezbędne do kompilacji.

Kompilacja z katalogu pakietu:

```bash
pdflatex -interaction=nonstopmode -halt-on-error Wyklad_4.tex
pdflatex -interaction=nonstopmode -halt-on-error Wyklad_4.tex
```

Wymagane: TeX Live/MiKTeX z pakietami użytymi w oryginalnej preambule, w tym beamer, lmodern, ragged2e, multimedia, textpos i TikZ. Oryginalny materiał oraz skrypty i dane w katalogu materialy pozostawiono bez zmian. Poprzednia wersja przebudowana nie jest częścią tego pakietu.
