# Wykład 4 — od symptomu do wiarygodnej decyzji

30 slajdów: 26 slajdów części głównej na 90 minut oraz 4 slajdy dodatku i źródeł. Notatki zawierają czasy, pytania, odpowiedzi i ograniczenia przykładów. Materiał po polsku, dla studiów magisterskich; dydaktyka oparta na problemie i eksperymencie, bez afiliacji MIT.

## Pliki

- Wyklad_4_przebudowany.pdf — slajdy.
- Wyklad_4_przebudowany.tex — edytowalne źródło Beamer.
- Notatki_prowadzacego.md — scenariusz 90 minut.
- materialy/ — kopie dostarczonych skryptów i danych oraz odtworzone wyniki.
- generuj.py — generator slajdów i notatek; zmiany można wprowadzać tu albo bezpośrednio w TEX. Ponowne uruchomienie generatora zastępuje TEX i notatki.

## Odtworzenie

Python 3 z numpy, pandas, scipy, matplotlib; LaTeX z Beamer, lmodern, TikZ i booktabs. Z katalogu pakietu:

```bash
MPLCONFIGDIR=/tmp/mpl-wyklad4 python materialy/analizy_okno.py
MPLCONFIGDIR=/tmp/mpl-wyklad4 python materialy/ocena_holdout.py
pdflatex -interaction=nonstopmode -halt-on-error Wyklad_4_przebudowany.tex
pdflatex -interaction=nonstopmode -halt-on-error Wyklad_4_przebudowany.tex
```

Pierwszy skrypt tworzy parametry_analiz.json i katalog Rys; drugi korzysta z tych parametrów. Skrypty użytkownika zachowano bez zmian. Pozostałych dostarczonych skryptów nie trzeba uruchamiać do budowy tej prezentacji.

## Walidacja i zakres

Ponownie uruchomiono analizy_okno.py oraz ocena_holdout.py; asercje przeszły. Wyniki HOLDOUT: TN=226, FP=0, FN=17, TP=203; opóźnienie 17 s, udział czasu alarmu z pamięcią 92,27%, pokrycie czasu F2 71,43%. Bez pamięci TP=62 i udział 28,18%. Mianowniki obejmują wyłącznie ocenione próbki. Luka danych i ponowne zbieranie okna są wyłączone z oceny.

Nie wykonano walidacji detektorów na F1, F3 ani F4. Proponowany model zależny od fazy i przykładowe kryteria akceptacji mają charakter dydaktyczny. Nie są wynikami nowego eksperymentu. Oryginalny wykład ma 71 stron i odwołuje się do osobnych ilustracji Rys; nowa prezentacja jest samodzielną przebudową, nie reprodukcją wszystkich oryginalnych rysunków. Oryginalne załączniki i repozytorium pozostają bez zmian.
