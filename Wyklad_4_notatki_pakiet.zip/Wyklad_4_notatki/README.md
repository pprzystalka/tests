# Wykład 4 — notatki włączane i wyłączane w LaTeX

## Od czego zacząć

Otwórz **Wyklad_4_z_notatkami.tex** jako główny dokument. Slajdy mają oryginalną treść, kolejność i formatkę. Notatki obejmują wszystkie 71 slajdów.

W pliku **ustawienia_notatek.tex** zmień tylko cyfrę w poleceniu:

```tex
\providecommand{\TrybNotatek}{0}
```

- **0** — same slajdy, bez widocznych notatek; tryb domyślny do prezentowania studentom.
- **1** — slajd po lewej, notatki po prawej, jedna szeroka strona PDF na slajd. Do widoku prezentera potrzebny jest czytnik obsługujący dwa ekrany; zwykły czytnik pokaże obie części.
- **2** — tylko notatki, po jednej stronie na slajd; do przygotowania prowadzącego lub druku.

Po zmianie trybu skompiluj dokument dwukrotnie. Nie trzeba komentować notatek ani zmieniać slajdów.

## Gdzie edytować treść

Katalog **notatki/** zawiera pliki **01.tex** do **71.tex**, zgodnie z numerami pierwotnego wykładu. Każda notatka zawiera omówienie, pytanie i odpowiedź oraz uwagę lub przejście. To wskazówki prowadzącego, nie tekst do odczytania słowo w słowo. Ustne doprecyzowania nie zmieniają slajdów.

Nie edytuj pliku tresc_notatek.txt po zmianach w notatki/*.tex, chyba że zamierzasz świadomie użyć generatora. Uruchomienie generuj_notatki.py odtwarza i zastępuje pliki notatek i kopię z notatkami na podstawie tego pliku.

## Oryginał pozostaje oryginałem

**Wyklad_4.tex** jest identyczną bajtowo kopią załączonego przez użytkownika oryginalnego TEX. Nie użyto wcześniejszej przebudowy ani wersji z poprawkami czytelności. **Wyklad_4_z_notatkami.tex** dodaje wyłącznie wczytanie ustawień i polecenia `\note{\input{notatki/NN.tex}}` przed końcem każdej ramki.

Gdy dodasz/usuniesz slajdy, odpowiednio zaktualizuj przypisania notatek. Beamer nie analizuje znaczenia treści ani nie przesuwa automatycznie plików notatek.

Katalog **Rys/** zawiera ilustracje potrzebne do kompilacji. Ilustracje rastrowe odzyskano z oryginalnego PDF; wykresy odtworzono z dostarczonych skryptów i danych. Źródła pierwotne pozostawiono bez zmian.

## Kompilacja

Wymagany TeX Live lub MiKTeX z pakietami z oryginalnej preambuły oraz pgfpages (pakiet PGF/TikZ). Uruchamiaj polecenia w katalogu, w którym znajduje się główny TEX, albo zaimportuj cały katalog do Overleaf i wybierz Wyklad_4_z_notatkami.tex jako Main document.

```bash
pdflatex -interaction=nonstopmode -halt-on-error Wyklad_4_z_notatkami.tex
pdflatex -interaction=nonstopmode -halt-on-error Wyklad_4_z_notatkami.tex
```

Można też wybrać tryb bez edycji plików, np.:

```bash
pdflatex -jobname=Wyklad_4_slajdy_i_notatki '\def\TrybNotatek{1}\input{Wyklad_4_z_notatkami.tex}'
```

Uruchom dwukrotnie. Osobne nazwy jobname zapobiegają nadpisywaniu różnych wersji PDF.

W trybie 2 Beamer nie wypisuje slajdów bibliografii i może zgłaszać niezdefiniowane cytowania z niewidocznych slajdów; notatki nie zawierają tych cytowań. W trybie prezentacji i trybie obok siebie odwołania są rozwiązane po dwóch kompilacjach.

## Gotowe PDF i weryfikacja

- **Wyklad_4_slajdy_i_notatki.pdf** — widok obok siebie.
- **Wyklad_4_same_notatki.pdf** — same notatki.

Sprawdzono wszystkie trzy tryby, po 71 stron. W trybie 0 wszystkie 71 slajdów jest identycznych pikselowo z oryginalnym TEX skompilowanym w tym samym środowisku. Nie porównujemy bajtów PDF: zależą od daty, wersji LaTeX i metadanych. Sprawdzono również granice stron notatek. Szczegóły: WERYFIKACJA.txt.
