from pathlib import Path
import re
root=Path(__file__).parent
source=(root/'Wyklad_4.tex').read_text()
rows=[line.split('|') for line in (root/'tresc_notatek.txt').read_text().splitlines() if line.strip()]
assert len(rows)==71 and all(len(row)==5 for row in rows)
def esc(t):
 for a,b in [('&',r'\&'),('%',r'\%'),('_',r'\_'),('#',r'\#')]:t=t.replace(a,b)
 return t
for i,title,explain,question,transition in rows:
 text=r'\textbf{'+esc(title)+r'}\par\smallskip'+'\n'
 text=text.replace('\\n','\n')
 text+=r'\textbf{Omówienie.} '+esc(explain)+'\n\n'
 text+=r'\textbf{Pytanie i odpowiedź.} '+esc(question)+'\n\n'
 text+=r'\textbf{Uwaga / przejście.} '+esc(transition)+'\n'
 (root/'notatki'/f'{int(i):02}.tex').write_text(text)
idx=0
def inject(match):
 global idx
 idx+=1
 return match.group(0).replace(r'\end{frame}',f'\\note{{\\input{{notatki/{idx:02}.tex}}}}%\n'+r'\end{frame}')
annotated=re.sub(r'\\begin\{frame\}.*?\\end\{frame\}',inject,source,flags=re.S)
assert idx==71
annotated=annotated.replace(r'\begin{document}',r'\input{ustawienia_notatek.tex}'+'\n'+r'\begin{document}',1)
(root/'Wyklad_4_z_notatkami.tex').write_text(annotated)
# Dowód, że dodano tylko konfigurację i polecenia notatek.
stripped=annotated.replace('\\input{ustawienia_notatek.tex}\n','',1)
stripped=re.sub(r'\\note\{\\input\{notatki/\d{2}\.tex\}\}%\n','',stripped)
assert stripped==source
print('71 notatek; treść oryginału zachowana dokładnie')
